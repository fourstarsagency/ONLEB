import { useState, useEffect } from 'react';
import { Search, ShoppingBag, Menu, X, User } from 'lucide-react';
import { useCartStore } from '@/store/cartStore';
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from '@/components/ui/sheet';
import { Input } from '@/components/ui/input';

interface HeaderProps {
  onNavigate: (page: string) => void;
  currentPage: string;
}

export function Header({ onNavigate, currentPage }: HeaderProps) {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const { getTotalItems, toggleCart } = useCartStore();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 100);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navItems = [
    { label: 'Shop', page: 'shop' },
    { label: 'Collections', page: 'collections' },
    { label: 'Lookbook', page: 'lookbook' },
    { label: 'Contact', page: 'contact' },
  ];

  const handleNavClick = (page: string) => {
    onNavigate(page);
    setIsMobileMenuOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <>
      <header
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
          isScrolled
            ? 'bg-[#0B0B0D]/90 backdrop-blur-md py-4'
            : 'bg-transparent py-6'
        }`}
      >
        <div className="w-full px-6 lg:px-12 flex items-center justify-between">
          {/* Logo */}
          <button
            onClick={() => handleNavClick('home')}
            className="font-mono text-xl tracking-[0.2em] text-[#F4F1EA] hover:text-[#C9A86C] transition-colors"
          >
            ONLEB
          </button>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center gap-10">
            {navItems.map((item) => (
              <button
                key={item.page}
                onClick={() => handleNavClick(item.page)}
                className={`nav-link ${
                  currentPage === item.page ? 'text-[#C9A86C]' : ''
                }`}
              >
                {item.label}
              </button>
            ))}
          </nav>

          {/* Right Actions */}
          <div className="flex items-center gap-4">
            {/* Search */}
            <Sheet open={isSearchOpen} onOpenChange={setIsSearchOpen}>
              <SheetTrigger asChild>
                <button className="p-2 text-[#F4F1EA] hover:text-[#C9A86C] transition-colors">
                  <Search className="w-5 h-5" />
                </button>
              </SheetTrigger>
              <SheetContent side="top" className="bg-[#0B0B0D]/95 border-b border-[#C9A86C]/20">
                <SheetHeader>
                  <SheetTitle className="text-[#F4F1EA] font-mono tracking-wider">SEARCH</SheetTitle>
                </SheetHeader>
                <div className="py-8">
                  <Input
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Search products..."
                    className="bg-[#141419] border-[#C9A86C]/30 text-[#F4F1EA] placeholder:text-[#A7A29A] h-14 text-lg"
                  />
                </div>
              </SheetContent>
            </Sheet>

            {/* User */}
            <button 
              onClick={() => handleNavClick('account')}
              className="hidden sm:block p-2 text-[#F4F1EA] hover:text-[#C9A86C] transition-colors"
            >
              <User className="w-5 h-5" />
            </button>

            {/* Cart */}
            <button
              onClick={toggleCart}
              className="p-2 text-[#F4F1EA] hover:text-[#C9A86C] transition-colors relative"
            >
              <ShoppingBag className="w-5 h-5" />
              {getTotalItems() > 0 && (
                <span className="absolute -top-1 -right-1 w-5 h-5 bg-[#C9A86C] text-[#0B0B0D] text-xs font-bold rounded-full flex items-center justify-center">
                  {getTotalItems()}
                </span>
              )}
            </button>

            {/* Mobile Menu Toggle */}
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="lg:hidden p-2 text-[#F4F1EA] hover:text-[#C9A86C] transition-colors"
            >
              {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        <div
          className={`lg:hidden absolute top-full left-0 right-0 bg-[#0B0B0D]/98 backdrop-blur-md transition-all duration-300 ${
            isMobileMenuOpen ? 'opacity-100 visible' : 'opacity-0 invisible'
          }`}
        >
          <nav className="flex flex-col py-6 px-6">
            {navItems.map((item) => (
              <button
                key={item.page}
                onClick={() => handleNavClick(item.page)}
                className="py-4 text-left text-[#F4F1EA] hover:text-[#C9A86C] transition-colors text-lg font-medium border-b border-[#F4F1EA]/10"
              >
                {item.label}
              </button>
            ))}
            <button
              onClick={() => handleNavClick('account')}
              className="py-4 text-left text-[#F4F1EA] hover:text-[#C9A86C] transition-colors text-lg font-medium"
            >
              My Account
            </button>
          </nav>
        </div>
      </header>
    </>
  );
}
