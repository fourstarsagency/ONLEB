import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetFooter } from '@/components/ui/sheet';
import { Button } from '@/components/ui/button';
import { useCartStore } from '@/store/cartStore';
import { Minus, Plus, X, ShoppingBag } from 'lucide-react';

interface CartDrawerProps {
  onCheckout: () => void;
}

export function CartDrawer({ onCheckout }: CartDrawerProps) {
  const { items, isOpen, setCartOpen, removeItem, updateQuantity, getTotalPrice, clearCart } = useCartStore();

  const handleCheckout = () => {
    setCartOpen(false);
    onCheckout();
  };

  return (
    <Sheet open={isOpen} onOpenChange={setCartOpen}>
      <SheetContent className="bg-[#0B0B0D] border-l border-[#C9A86C]/20 w-full sm:max-w-md flex flex-col">
        <SheetHeader className="border-b border-[#F4F1EA]/10 pb-4">
          <SheetTitle className="text-[#F4F1EA] font-mono tracking-wider flex items-center gap-3">
            <ShoppingBag className="w-5 h-5 text-[#C9A86C]" />
            YOUR BAG
          </SheetTitle>
        </SheetHeader>

        <div className="flex-1 overflow-auto py-4">
          {items.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full text-center">
              <ShoppingBag className="w-16 h-16 text-[#A7A29A] mb-4" />
              <p className="text-[#F4F1EA] text-lg font-medium mb-2">Your bag is empty</p>
              <p className="text-[#A7A29A] text-sm">Add items to get started</p>
            </div>
          ) : (
            <div className="space-y-4">
              {items.map((item) => (
                <div
                  key={`${item.id}-${item.size}`}
                  className="flex gap-4 p-3 bg-[#141419] rounded-lg"
                >
                  <img
                    src={item.image}
                    alt={item.name}
                    className="w-20 h-24 object-cover rounded-md"
                  />
                  <div className="flex-1 flex flex-col">
                    <div className="flex justify-between items-start">
                      <div>
                        <h4 className="text-[#F4F1EA] text-sm font-medium line-clamp-1">
                          {item.name}
                        </h4>
                        <p className="text-[#A7A29A] text-xs mt-1">Size: {item.size}</p>
                      </div>
                      <button
                        onClick={() => removeItem(item.id, item.size)}
                        className="text-[#A7A29A] hover:text-[#C9A86C] transition-colors"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                    <div className="flex-1" />
                    <div className="flex justify-between items-center">
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() =>
                            updateQuantity(item.id, item.size, item.quantity - 1)
                          }
                          className="w-7 h-7 flex items-center justify-center bg-[#0B0B0D] rounded text-[#F4F1EA] hover:bg-[#C9A86C] hover:text-[#0B0B0D] transition-colors"
                        >
                          <Minus className="w-3 h-3" />
                        </button>
                        <span className="text-[#F4F1EA] text-sm w-6 text-center">
                          {item.quantity}
                        </span>
                        <button
                          onClick={() =>
                            updateQuantity(item.id, item.size, item.quantity + 1)
                          }
                          className="w-7 h-7 flex items-center justify-center bg-[#0B0B0D] rounded text-[#F4F1EA] hover:bg-[#C9A86C] hover:text-[#0B0B0D] transition-colors"
                        >
                          <Plus className="w-3 h-3" />
                        </button>
                      </div>
                      <span className="text-[#C9A86C] font-medium">
                        ${(item.price * item.quantity).toFixed(0)}
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {items.length > 0 && (
          <SheetFooter className="border-t border-[#F4F1EA]/10 pt-4 flex-col gap-4">
            <div className="flex justify-between items-center w-full">
              <span className="text-[#A7A29A]">Subtotal</span>
              <span className="text-[#F4F1EA] text-xl font-bold">
                ${getTotalPrice().toFixed(0)}
              </span>
            </div>
            <p className="text-[#A7A29A] text-xs text-center">
              Shipping and taxes calculated at checkout
            </p>
            <Button
              onClick={handleCheckout}
              className="w-full btn-gold h-12 text-sm font-semibold tracking-wider"
            >
              CHECKOUT
            </Button>
            <button
              onClick={clearCart}
              className="text-[#A7A29A] text-sm hover:text-[#C9A86C] transition-colors"
            >
              Clear Bag
            </button>
          </SheetFooter>
        )}
      </SheetContent>
    </Sheet>
  );
}
