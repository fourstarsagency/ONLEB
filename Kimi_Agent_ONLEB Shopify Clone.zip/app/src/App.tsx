import { useEffect, useState, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Toaster } from '@/components/ui/sonner';
import { Header } from '@/components/Header';
import { CartDrawer } from '@/components/CartDrawer';
import { HeroSection } from '@/sections/HeroSection';
import { FeaturedCoatSection } from '@/sections/FeaturedCoatSection';
import { CollectionGridSection } from '@/sections/CollectionGridSection';
import { TrenchSection } from '@/sections/TrenchSection';
import { SignatureBlazerSection } from '@/sections/SignatureBlazerSection';
import { RunwaySection } from '@/sections/RunwaySection';
import { ShopDropSection } from '@/sections/ShopDropSection';
import { BrandStorySection } from '@/sections/BrandStorySection';
import { FooterSection } from '@/sections/FooterSection';
import { ShopPage } from '@/pages/ShopPage';
import { ProductDetailPage } from '@/pages/ProductDetailPage';
import { CheckoutPage } from '@/pages/CheckoutPage';

gsap.registerPlugin(ScrollTrigger);

function App() {
  const [currentPage, setCurrentPage] = useState<'home' | 'shop' | 'product' | 'checkout' | 'collections' | 'lookbook' | 'contact' | 'account'>('home');
  const [selectedProductId, setSelectedProductId] = useState<string>('');
  const mainRef = useRef<HTMLDivElement>(null);
  const snapTriggerRef = useRef<ScrollTrigger | null>(null);

  // Global scroll snap for pinned sections
  useEffect(() => {
    if (currentPage !== 'home') return;

    // Wait for all ScrollTriggers to be created
    const timer = setTimeout(() => {
      const pinned = ScrollTrigger.getAll()
        .filter(st => st.vars.pin)
        .sort((a, b) => a.start - b.start);
      
      const maxScroll = ScrollTrigger.maxScroll(window);
      
      if (!maxScroll || pinned.length === 0) return;

      // Build ranges and snap targets from pinned sections
      const pinnedRanges = pinned.map(st => ({
        start: st.start / maxScroll,
        end: (st.end ?? st.start) / maxScroll,
        center: (st.start + ((st.end ?? st.start) - st.start) * 0.5) / maxScroll,
      }));

      // Create global snap
      snapTriggerRef.current = ScrollTrigger.create({
        snap: {
          snapTo: (value: number) => {
            // Check if within any pinned range (with buffer)
            const inPinned = pinnedRanges.some(
              r => value >= r.start - 0.02 && value <= r.end + 0.02
            );
            
            if (!inPinned) return value; // Flowing section: free scroll

            // Find nearest pinned center
            const target = pinnedRanges.reduce(
              (closest, r) =>
                Math.abs(r.center - value) < Math.abs(closest - value)
                  ? r.center
                  : closest,
              pinnedRanges[0]?.center ?? 0
            );

            return target;
          },
          duration: { min: 0.15, max: 0.35 },
          delay: 0,
          ease: 'power2.out',
        },
      });
    }, 500);

    return () => {
      clearTimeout(timer);
      if (snapTriggerRef.current) {
        snapTriggerRef.current.kill();
      }
    };
  }, [currentPage]);

  // Cleanup all ScrollTriggers when leaving home page
  useEffect(() => {
    if (currentPage !== 'home') {
      ScrollTrigger.getAll().forEach(st => st.kill());
    }
  }, [currentPage]);

  const handleNavigate = (page: string) => {
    switch (page) {
      case 'home':
        setCurrentPage('home');
        break;
      case 'shop':
        setCurrentPage('shop');
        break;
      case 'collections':
        setCurrentPage('collections');
        break;
      case 'lookbook':
        setCurrentPage('lookbook');
        break;
      case 'contact':
        setCurrentPage('contact');
        break;
      case 'account':
        setCurrentPage('account');
        break;
      default:
        setCurrentPage('home');
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleProductClick = (productId: string) => {
    setSelectedProductId(productId);
    setCurrentPage('product');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleCheckout = () => {
    setCurrentPage('checkout');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleCheckoutComplete = () => {
    setCurrentPage('home');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div ref={mainRef} className="relative">
      <Toaster 
        position="top-center" 
        toastOptions={{
          style: {
            background: '#141419',
            color: '#F4F1EA',
            border: '1px solid rgba(201, 168, 108, 0.3)',
          },
        }}
      />
      
      {/* Grain Overlay */}
      <div className="grain-overlay" />

      {/* Header */}
      <Header onNavigate={handleNavigate} currentPage={currentPage} />

      {/* Cart Drawer */}
      <CartDrawer onCheckout={handleCheckout} />

      {/* Main Content */}
      {currentPage === 'home' && (
        <main className="relative">
          <HeroSection onShopNow={() => handleNavigate('shop')} />
          <FeaturedCoatSection onShopCoats={() => handleNavigate('shop')} />
          <CollectionGridSection onViewCollection={() => handleNavigate('shop')} />
          <TrenchSection onShopOuterwear={() => handleNavigate('shop')} />
          <SignatureBlazerSection />
          <RunwaySection onShopNow={() => handleNavigate('shop')} />
          <ShopDropSection onViewAll={() => handleNavigate('shop')} />
          <BrandStorySection onReadStory={() => handleNavigate('collections')} />
          <FooterSection />
        </main>
      )}

      {currentPage === 'shop' && (
        <ShopPage onProductClick={handleProductClick} />
      )}

      {currentPage === 'product' && selectedProductId && (
        <ProductDetailPage 
          productId={selectedProductId} 
          onBack={() => setCurrentPage('shop')} 
        />
      )}

      {currentPage === 'checkout' && (
        <CheckoutPage 
          onBack={() => setCurrentPage('shop')} 
          onComplete={handleCheckoutComplete}
        />
      )}

      {currentPage === 'collections' && (
        <div className="min-h-screen bg-[#0B0B0D] pt-24 pb-16 flex items-center justify-center">
          <div className="text-center">
            <h1 className="text-[#F4F1EA] text-4xl font-black tracking-wider mb-4">COLLECTIONS</h1>
            <p className="text-[#A7A29A] mb-8">Coming Soon</p>
            <button onClick={() => handleNavigate('home')} className="btn-gold">
              BACK TO HOME
            </button>
          </div>
        </div>
      )}

      {currentPage === 'lookbook' && (
        <div className="min-h-screen bg-[#0B0B0D] pt-24 pb-16 flex items-center justify-center">
          <div className="text-center">
            <h1 className="text-[#F4F1EA] text-4xl font-black tracking-wider mb-4">LOOKBOOK</h1>
            <p className="text-[#A7A29A] mb-8">Coming Soon</p>
            <button onClick={() => handleNavigate('home')} className="btn-gold">
              BACK TO HOME
            </button>
          </div>
        </div>
      )}

      {currentPage === 'contact' && (
        <div className="min-h-screen bg-[#0B0B0D] pt-24 pb-16 flex items-center justify-center">
          <div className="text-center">
            <h1 className="text-[#F4F1EA] text-4xl font-black tracking-wider mb-4">CONTACT</h1>
            <p className="text-[#A7A29A] mb-4">Email: hello@onleb.com</p>
            <p className="text-[#A7A29A] mb-8">Phone: +1 (555) 123-4567</p>
            <button onClick={() => handleNavigate('home')} className="btn-gold">
              BACK TO HOME
            </button>
          </div>
        </div>
      )}

      {currentPage === 'account' && (
        <div className="min-h-screen bg-[#0B0B0D] pt-24 pb-16 flex items-center justify-center">
          <div className="text-center">
            <h1 className="text-[#F4F1EA] text-4xl font-black tracking-wider mb-4">MY ACCOUNT</h1>
            <p className="text-[#A7A29A] mb-8">Sign in or create an account</p>
            <div className="flex gap-4 justify-center">
              <button className="btn-gold">SIGN IN</button>
              <button className="btn-outline">REGISTER</button>
            </div>
            <button onClick={() => handleNavigate('home')} className="mt-8 text-[#A7A29A] hover:text-[#C9A86C]">
              Back to Home
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

export default App;
