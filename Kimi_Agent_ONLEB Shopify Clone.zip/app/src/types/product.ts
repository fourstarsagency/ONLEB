export interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  originalPrice?: number;
  images: string[];
  category: string;
  sizes: string[];
  inStock: boolean;
  featured?: boolean;
  new?: boolean;
  tags?: string[];
}

export interface Category {
  id: string;
  name: string;
  image: string;
  count: number;
}

export const products: Product[] = [
  {
    id: 'structured-blazer',
    name: 'ONLEB — Structured Blazer',
    description: 'A meticulously tailored blazer crafted from premium wool blend. Features sharp shoulders, a nipped waist, and signature gold-tone hardware. The definitive piece for the modern wardrobe.',
    price: 189,
    originalPrice: 249,
    images: ['/signature_blazer_left.jpg', '/signature_blazer_right.jpg', '/product_thumb_blazer.jpg'],
    category: 'Blazers',
    sizes: ['XS', 'S', 'M', 'L', 'XL'],
    inStock: true,
    featured: true,
    new: true,
    tags: ['bestseller', 'tailored']
  },
  {
    id: 'trench-coat',
    name: 'ONLEB — Trench Coat',
    description: 'The modern reinterpretation of a classic. Water-resistant cotton gabardine with a detachable belt, storm flaps, and our signature gold hardware. Designed for movement.',
    price: 240,
    originalPrice: 320,
    images: ['/trench_left.jpg', '/trench_right.jpg', '/product_thumb_trench.jpg'],
    category: 'Outerwear',
    sizes: ['XS', 'S', 'M', 'L', 'XL'],
    inStock: true,
    featured: true,
    tags: ['outerwear', 'classic']
  },
  {
    id: 'statement-coat',
    name: 'ONLEB — Statement Coat',
    description: 'An oversized silhouette in luxurious cashmere wool. Dramatic lapels, dropped shoulders, and a cocoon shape that commands attention.',
    price: 395,
    images: ['/featured_coat_left.jpg', '/featured_coat_right.jpg'],
    category: 'Outerwear',
    sizes: ['XS', 'S', 'M', 'L'],
    inStock: true,
    featured: true,
    tags: ['luxury', 'winter']
  },
  {
    id: 'gold-chain-necklace',
    name: 'ONLEB — Gold Chain Necklace',
    description: 'Bold, sculptural chain links in 18k gold-plated brass. A statement piece that elevates any ensemble.',
    price: 125,
    images: ['/grid_look_02.jpg'],
    category: 'Accessories',
    sizes: ['One Size'],
    inStock: true,
    new: true,
    tags: ['jewelry', 'gold']
  },
  {
    id: 'leather-combat-boots',
    name: 'ONLEB — Leather Combat Boots',
    description: 'Italian-crafted leather boots with chunky soles and gold eyelets. Built for the city streets.',
    price: 280,
    images: ['/grid_look_03.jpg'],
    category: 'Footwear',
    sizes: ['36', '37', '38', '39', '40', '41'],
    inStock: true,
    tags: ['footwear', 'leather']
  },
  {
    id: 'evening-gown',
    name: 'ONLEB — Evening Gown',
    description: 'A floor-length silk gown with dramatic draping and a thigh-high slit. The epitome of evening elegance.',
    price: 450,
    images: ['/grid_look_04.jpg'],
    category: 'Dresses',
    sizes: ['XS', 'S', 'M', 'L'],
    inStock: true,
    featured: true,
    tags: ['evening', 'gown']
  },
  {
    id: 'tailored-trousers',
    name: 'ONLEB — Tailored Trousers',
    description: 'High-waisted trousers with a wide leg and sharp crease. Crafted from Italian wool.',
    price: 165,
    images: ['/grid_blazer_left.jpg'],
    category: 'Trousers',
    sizes: ['XS', 'S', 'M', 'L', 'XL'],
    inStock: true,
    tags: ['tailored', 'essentials']
  },
  {
    id: 'silk-blouse',
    name: 'ONLEB — Silk Blouse',
    description: 'Fluid silk blouse with a draped neckline and gold button details. Effortless sophistication.',
    price: 145,
    images: ['/hero_left_blazer.jpg'],
    category: 'Tops',
    sizes: ['XS', 'S', 'M', 'L'],
    inStock: true,
    new: true,
    tags: ['silk', 'blouse']
  }
];

export const categories: Category[] = [
  { id: 'blazers', name: 'Blazers', image: '/signature_blazer_left.jpg', count: 12 },
  { id: 'outerwear', name: 'Outerwear', image: '/trench_left.jpg', count: 8 },
  { id: 'dresses', name: 'Dresses', image: '/grid_look_04.jpg', count: 15 },
  { id: 'accessories', name: 'Accessories', image: '/grid_look_02.jpg', count: 24 },
];
