import { useEffect, useRef, useLayoutEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

interface HeroSectionProps {
  onShopNow: () => void;
}

export function HeroSection({ onShopNow }: HeroSectionProps) {
  const sectionRef = useRef<HTMLDivElement>(null);
  const leftPanelRef = useRef<HTMLDivElement>(null);
  const rightPanelRef = useRef<HTMLDivElement>(null);
  const dividerRef = useRef<HTMLDivElement>(null);
  const logoRef = useRef<HTMLDivElement>(null);
  const taglineRef = useRef<HTMLDivElement>(null);
  const ctaRef = useRef<HTMLButtonElement>(null);
  const microLabelRef = useRef<HTMLDivElement>(null);

  // Auto-play entrance animation on load
  useEffect(() => {
    const ctx = gsap.context(() => {
      const tl = gsap.timeline({ defaults: { ease: 'power3.out' } });

      // Initial states
      gsap.set(leftPanelRef.current, { x: '-60vw' });
      gsap.set(rightPanelRef.current, { x: '60vw' });
      gsap.set(dividerRef.current, { scaleY: 0 });
      gsap.set(logoRef.current, { y: 24, opacity: 0 });
      gsap.set(taglineRef.current, { y: 18, opacity: 0 });
      gsap.set(ctaRef.current, { y: 14, scale: 0.96, opacity: 0 });
      gsap.set(microLabelRef.current, { y: -10, opacity: 0 });

      // Entrance animation
      tl.to([leftPanelRef.current, rightPanelRef.current], {
        x: 0,
        duration: 0.8,
        stagger: 0,
      })
        .to(dividerRef.current, {
          scaleY: 1,
          duration: 0.6,
        }, '-=0.4')
        .to(microLabelRef.current, {
          y: 0,
          opacity: 1,
          duration: 0.5,
        }, '-=0.3')
        .to(logoRef.current, {
          y: 0,
          opacity: 1,
          duration: 0.5,
        }, '-=0.3')
        .to(taglineRef.current, {
          y: 0,
          opacity: 1,
          duration: 0.5,
        }, '-=0.3')
        .to(ctaRef.current, {
          y: 0,
          scale: 1,
          opacity: 1,
          duration: 0.5,
        }, '-=0.3');
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  // Scroll-driven exit animation
  useLayoutEffect(() => {
    const ctx = gsap.context(() => {
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: sectionRef.current,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.6,
          onLeaveBack: () => {
            // Reset all elements to visible when scrolling back to top
            gsap.to([leftPanelRef.current, rightPanelRef.current], {
              x: 0,
              opacity: 1,
              duration: 0.3,
            });
            gsap.to(dividerRef.current, { scaleY: 1, duration: 0.3 });
            gsap.to([logoRef.current, taglineRef.current, ctaRef.current, microLabelRef.current], {
              y: 0,
              opacity: 1,
              duration: 0.3,
            });
          },
        },
      });

      // ENTRANCE (0-30%): Hold - elements already visible from load animation
      // SETTLE (30-70%): Static
      // EXIT (70-100%): Elements exit

      scrollTl
        .fromTo(
          leftPanelRef.current,
          { x: 0, opacity: 1 },
          { x: '-40vw', opacity: 0, ease: 'power2.in' },
          0.7
        )
        .fromTo(
          rightPanelRef.current,
          { x: 0, opacity: 1 },
          { x: '40vw', opacity: 0, ease: 'power2.in' },
          0.7
        )
        .fromTo(
          dividerRef.current,
          { scaleY: 1 },
          { scaleY: 0, ease: 'power2.in' },
          0.7
        )
        .fromTo(
          [logoRef.current, taglineRef.current, ctaRef.current, microLabelRef.current],
          { y: 0, opacity: 1 },
          { y: '-6vh', opacity: 0, ease: 'power2.in', stagger: 0.02 },
          0.7
        );
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      className="section-pinned bg-[#0B0B0D] z-10"
    >
      {/* Left Media Panel */}
      <div
        ref={leftPanelRef}
        className="absolute left-0 top-0 w-1/2 h-full overflow-hidden"
      >
        <img
          src="/hero_left_blazer.jpg"
          alt="Fashion model"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-transparent to-[#0B0B0D]/30" />
      </div>

      {/* Right Media Panel */}
      <div
        ref={rightPanelRef}
        className="absolute right-0 top-0 w-1/2 h-full overflow-hidden"
      >
        <img
          src="/hero_right_blazer.jpg"
          alt="Fashion model"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-l from-transparent to-[#0B0B0D]/30" />
      </div>

      {/* Center Divider */}
      <div
        ref={dividerRef}
        className="divider-line"
        style={{ transformOrigin: 'center' }}
      />

      {/* Micro Label */}
      <div
        ref={microLabelRef}
        className="absolute left-1/2 top-[7vh] -translate-x-1/2 micro-label"
      >
        SS26 LOOKBOOK
      </div>

      {/* Center Content */}
      <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
        {/* Logo */}
        <div
          ref={logoRef}
          className="text-[#F4F1EA] text-5xl md:text-7xl lg:text-8xl font-black tracking-[0.12em] mb-6"
          style={{ textShadow: '0 4px 30px rgba(0,0,0,0.5)' }}
        >
          ONLEB
        </div>

        {/* Tagline */}
        <div
          ref={taglineRef}
          className="text-[#F4F1EA]/90 text-lg md:text-xl tracking-[0.3em] font-light mb-10"
        >
          Style in Motion
        </div>

        {/* CTA Button */}
        <button
          ref={ctaRef}
          onClick={onShopNow}
          className="btn-gold pointer-events-auto text-sm tracking-[0.15em] font-semibold"
        >
          SHOP THE DROP
        </button>
      </div>
    </section>
  );
}
