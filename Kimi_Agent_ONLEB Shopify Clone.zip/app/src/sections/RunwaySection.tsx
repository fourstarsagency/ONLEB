import { useRef, useLayoutEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

interface RunwaySectionProps {
  onShopNow: () => void;
}

export function RunwaySection({ onShopNow }: RunwaySectionProps) {
  const sectionRef = useRef<HTMLDivElement>(null);
  const imageRef = useRef<HTMLImageElement>(null);
  const headlineRef = useRef<HTMLHeadingElement>(null);
  const ctaRef = useRef<HTMLButtonElement>(null);

  useLayoutEffect(() => {
    const ctx = gsap.context(() => {
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: sectionRef.current,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.6,
        },
      });

      // ENTRANCE (0-30%)
      scrollTl
        .fromTo(
          imageRef.current,
          { scale: 1.08, y: '8vh' },
          { scale: 1, y: 0, ease: 'none' },
          0
        )
        .fromTo(
          headlineRef.current,
          { y: '10vh', opacity: 0 },
          { y: 0, opacity: 1, ease: 'none' },
          0.1
        )
        .fromTo(
          ctaRef.current,
          { y: '6vh', opacity: 0 },
          { y: 0, opacity: 1, ease: 'none' },
          0.14
        );

      // EXIT (70-100%)
      scrollTl
        .to(imageRef.current, {
          scale: 1.05,
          opacity: 0,
          ease: 'power2.in',
        }, 0.7)
        .to(headlineRef.current, {
          y: '-8vh',
          opacity: 0,
          ease: 'power2.in',
        }, 0.7)
        .to(ctaRef.current, {
          y: '-4vh',
          opacity: 0,
          ease: 'power2.in',
        }, 0.72);
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      className="section-pinned bg-[#0B0B0D] z-[60]"
    >
      {/* Full-bleed Background Image */}
      <img
        ref={imageRef}
        src="/runway_wide_blazer.jpg"
        alt="New arrivals"
        className="absolute inset-0 w-full h-full object-cover"
      />
      
      {/* Dark overlay for text readability */}
      <div className="absolute inset-0 bg-gradient-to-t from-[#0B0B0D]/70 via-[#0B0B0D]/20 to-[#0B0B0D]/40" />

      {/* Center Content */}
      <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
        <h2
          ref={headlineRef}
          className="text-[#F4F1EA] text-5xl md:text-7xl lg:text-8xl font-black tracking-[0.12em] text-center mb-8"
          style={{ textShadow: '0 4px 50px rgba(0,0,0,0.8)' }}
        >
          NEW<br />ARRIVALS
        </h2>

        <button
          ref={ctaRef}
          onClick={onShopNow}
          className="btn-gold pointer-events-auto text-sm tracking-[0.15em] font-semibold"
        >
          SHOP NOW
        </button>
      </div>
    </section>
  );
}
