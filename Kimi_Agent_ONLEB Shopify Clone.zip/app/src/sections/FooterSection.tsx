import { useState, useRef, useLayoutEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Instagram, Send } from 'lucide-react';
import { toast } from 'sonner';

gsap.registerPlugin(ScrollTrigger);

export function FooterSection() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const newsletterRef = useRef<HTMLDivElement>(null);
  const footerLinksRef = useRef<HTMLDivElement>(null);
  const [email, setEmail] = useState('');

  useLayoutEffect(() => {
    const ctx = gsap.context(() => {
      gsap.fromTo(
        newsletterRef.current,
        { y: '6vh', opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.8,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 80%',
            end: 'top 50%',
            scrub: 1,
          },
        }
      );

      gsap.fromTo(
        footerLinksRef.current,
        { y: '4vh', opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.6,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 70%',
            end: 'top 45%',
            scrub: 1,
          },
        }
      );
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (email) {
      toast.success('Thank you for subscribing!');
      setEmail('');
    }
  };

  const footerLinks = {
    shop: ['New Arrivals', 'Blazers', 'Outerwear', 'Dresses', 'Accessories'],
    support: ['Shipping', 'Returns', 'Size Guide', 'Care Instructions'],
    company: ['About Us', 'Careers', 'Press', 'Sustainability'],
    legal: ['Privacy Policy', 'Terms of Service', 'Cookie Policy'],
  };

  return (
    <footer
      ref={sectionRef}
      className="relative bg-[#141419] py-20 lg:py-24 z-[90]"
    >
      <div className="max-w-7xl mx-auto px-6 lg:px-12">
        {/* Newsletter */}
        <div
          ref={newsletterRef}
          className="text-center mb-16 pb-16 border-b border-[#F4F1EA]/10"
        >
          <h3 className="text-[#F4F1EA] text-3xl md:text-4xl font-black tracking-[0.1em] mb-4">
            JOIN THE LIST
          </h3>
          <p className="text-[#A7A29A] text-sm md:text-base mb-8 max-w-md mx-auto">
            Early access to drops, lookbooks, and private sales.
          </p>

          <form onSubmit={handleSubscribe} className="flex flex-col sm:flex-row gap-3 justify-center max-w-md mx-auto">
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="Email address"
              className="input-dark flex-1 h-12"
              required
            />
            <button
              type="submit"
              className="btn-gold h-12 px-8 flex items-center justify-center gap-2"
            >
              <Send className="w-4 h-4" />
              SUBSCRIBE
            </button>
          </form>
        </div>

        {/* Footer Links */}
        <div
          ref={footerLinksRef}
          className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-16"
        >
          <div>
            <h4 className="text-[#F4F1EA] font-semibold text-sm tracking-wider mb-4">SHOP</h4>
            <ul className="space-y-2">
              {footerLinks.shop.map((link) => (
                <li key={link}>
                  <button className="text-[#A7A29A] text-sm hover:text-[#C9A86C] transition-colors">
                    {link}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="text-[#F4F1EA] font-semibold text-sm tracking-wider mb-4">SUPPORT</h4>
            <ul className="space-y-2">
              {footerLinks.support.map((link) => (
                <li key={link}>
                  <button className="text-[#A7A29A] text-sm hover:text-[#C9A86C] transition-colors">
                    {link}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="text-[#F4F1EA] font-semibold text-sm tracking-wider mb-4">COMPANY</h4>
            <ul className="space-y-2">
              {footerLinks.company.map((link) => (
                <li key={link}>
                  <button className="text-[#A7A29A] text-sm hover:text-[#C9A86C] transition-colors">
                    {link}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="text-[#F4F1EA] font-semibold text-sm tracking-wider mb-4">LEGAL</h4>
            <ul className="space-y-2">
              {footerLinks.legal.map((link) => (
                <li key={link}>
                  <button className="text-[#A7A29A] text-sm hover:text-[#C9A86C] transition-colors">
                    {link}
                  </button>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="flex flex-col md:flex-row items-center justify-between pt-8 border-t border-[#F4F1EA]/10">
          <p className="text-[#A7A29A] text-sm mb-4 md:mb-0">
            © ONLEB 2026. All rights reserved.
          </p>

          <div className="flex items-center gap-6">
            <a
              href="https://instagram.com"
              target="_blank"
              rel="noopener noreferrer"
              className="text-[#A7A29A] hover:text-[#C9A86C] transition-colors"
            >
              <Instagram className="w-5 h-5" />
            </a>
            <a
              href="https://pinterest.com"
              target="_blank"
              rel="noopener noreferrer"
              className="text-[#A7A29A] hover:text-[#C9A86C] transition-colors"
            >
              <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                <path d="M12 0C5.373 0 0 5.373 0 12c0 5.084 3.163 9.426 7.627 11.174-.105-.949-.2-2.405.042-3.441.218-.937 1.407-5.965 1.407-5.965s-.359-.719-.359-1.782c0-1.668.967-2.914 2.171-2.914 1.023 0 1.518.769 1.518 1.69 0 1.029-.655 2.568-.994 3.995-.283 1.194.599 2.169 1.777 2.169 2.133 0 3.772-2.249 3.772-5.495 0-2.873-2.064-4.882-5.012-4.882-3.414 0-5.418 2.561-5.418 5.207 0 1.031.397 2.138.893 2.738.098.119.112.224.083.345l-.333 1.36c-.053.22-.174.267-.402.161-1.499-.698-2.436-2.889-2.436-4.649 0-3.785 2.75-7.262 7.929-7.262 4.163 0 7.398 2.967 7.398 6.931 0 4.136-2.607 7.464-6.227 7.464-1.216 0-2.359-.632-2.75-1.378l-.748 2.853c-.271 1.043-1.002 2.35-1.492 3.146C9.57 23.812 10.763 24 12 24c6.627 0 12-5.373 12-12S18.627 0 12 0z"/>
              </svg>
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}
