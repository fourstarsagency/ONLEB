import { useRef, useLayoutEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

interface CollectionGridSectionProps {
  onViewCollection: () => void;
}

export function CollectionGridSection({ onViewCollection }: CollectionGridSectionProps) {
  const sectionRef = useRef<HTMLDivElement>(null);
  const leftPanelRef = useRef<HTMLDivElement>(null);
  const gridContainerRef = useRef<HTMLDivElement>(null);
  const gridCellsRef = useRef<(HTMLDivElement | null)[]>([]);
  const headlineRef = useRef<HTMLHeadingElement>(null);
  const ctaRef = useRef<HTMLButtonElement>(null);
  const microLabelRef = useRef<HTMLDivElement>(null);

  useLayoutEffect(() => {
    const ctx = gsap.context(() => {
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: sectionRef.current,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.6,
        },
      });

      // ENTRANCE (0-30%)
      scrollTl
        .fromTo(
          leftPanelRef.current,
          { x: '-60vw', opacity: 1 },
          { x: 0, opacity: 1, ease: 'none' },
          0
        )
        .fromTo(
          gridContainerRef.current,
          { x: '60vw', opacity: 1 },
          { x: 0, opacity: 1, ease: 'none' },
          0
        )
        .fromTo(
          microLabelRef.current,
          { y: '3vh', opacity: 0 },
          { y: 0, opacity: 1, ease: 'none' },
          0.08
        )
        .fromTo(
          headlineRef.current,
          { y: '10vh', opacity: 0 },
          { y: 0, opacity: 1, ease: 'none' },
          0.1
        )
        .fromTo(
          ctaRef.current,
          { y: '6vh', opacity: 0 },
          { y: 0, opacity: 1, ease: 'none' },
          0.16
        );

      // Grid cells staggered entrance
      gridCellsRef.current.forEach((cell, i) => {
        if (cell) {
          scrollTl.fromTo(
            cell,
            { scale: 0.86, opacity: 0 },
            { scale: 1, opacity: 1, ease: 'none' },
            0.1 + i * 0.02
          );
        }
      });

      // EXIT (70-100%)
      scrollTl
        .to(leftPanelRef.current, {
          x: '-40vw',
          opacity: 0,
          ease: 'power2.in',
        }, 0.7)
        .to(gridContainerRef.current, {
          x: '40vw',
          opacity: 0,
          ease: 'power2.in',
        }, 0.7)
        .to(microLabelRef.current, {
          y: '-3vh',
          opacity: 0,
          ease: 'power2.in',
        }, 0.7)
        .to(headlineRef.current, {
          y: '-8vh',
          opacity: 0,
          ease: 'power2.in',
        }, 0.7)
        .to(ctaRef.current, {
          y: '-4vh',
          opacity: 0,
          ease: 'power2.in',
        }, 0.72);

      gridCellsRef.current.forEach((cell) => {
        if (cell) {
          scrollTl.to(cell, {
            scale: 0.92,
            opacity: 0,
            ease: 'power2.in',
          }, 0.7);
        }
      });
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  const gridImages = [
    '/grid_look_01.jpg',
    '/grid_look_02.jpg',
    '/grid_look_03.jpg',
    '/grid_look_04.jpg',
  ];

  return (
    <section
      ref={sectionRef}
      className="section-pinned bg-[#0B0B0D] z-30"
    >
      {/* Left Media Panel */}
      <div
        ref={leftPanelRef}
        className="absolute left-0 top-0 w-1/2 h-full overflow-hidden"
      >
        <img
          src="/grid_blazer_left.jpg"
          alt="Curated looks"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-transparent to-[#0B0B0D]/40" />
      </div>

      {/* Right Grid Panel */}
      <div
        ref={gridContainerRef}
        className="absolute right-0 top-0 w-1/2 h-full flex items-center justify-center p-8 lg:p-16"
      >
        <div className="grid grid-cols-2 gap-4 w-full max-w-lg">
          {gridImages.map((img, i) => (
            <div
              key={i}
              ref={(el) => { gridCellsRef.current[i] = el; }}
              className="aspect-[4/5] rounded-xl overflow-hidden"
            >
              <img
                src={img}
                alt={`Look ${i + 1}`}
                className="w-full h-full object-cover hover:scale-105 transition-transform duration-500"
              />
            </div>
          ))}
        </div>
      </div>

      {/* Center Content */}
      <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
        <div
          ref={microLabelRef}
          className="micro-label mb-4"
        >
          BROWSE
        </div>

        <h2
          ref={headlineRef}
          className="text-[#F4F1EA] text-4xl md:text-6xl lg:text-7xl font-black tracking-[0.1em] text-center mb-8"
          style={{ textShadow: '0 4px 40px rgba(0,0,0,0.7)' }}
        >
          CURATED<br />LOOKS
        </h2>

        <button
          ref={ctaRef}
          onClick={onViewCollection}
          className="btn-gold pointer-events-auto text-sm tracking-[0.15em] font-semibold"
        >
          VIEW COLLECTION
        </button>
      </div>
    </section>
  );
}
