import { useRef, useLayoutEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { useCartStore } from '@/store/cartStore';
import { products } from '@/types/product';

gsap.registerPlugin(ScrollTrigger);

export function SignatureBlazerSection() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const leftPanelRef = useRef<HTMLDivElement>(null);
  const rightPanelRef = useRef<HTMLDivElement>(null);
  const dividerRef = useRef<HTMLDivElement>(null);
  const headlineRef = useRef<HTMLHeadingElement>(null);
  const priceRef = useRef<HTMLParagraphElement>(null);
  const ctaRef = useRef<HTMLButtonElement>(null);
  const { addItem, toggleCart } = useCartStore();

  const blazer = products.find(p => p.id === 'structured-blazer');

  const handleAddToBag = () => {
    if (blazer) {
      addItem({
        id: blazer.id,
        name: blazer.name,
        price: blazer.price,
        image: blazer.images[0],
        size: 'M',
      });
      toggleCart();
    }
  };

  useLayoutEffect(() => {
    const ctx = gsap.context(() => {
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: sectionRef.current,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.6,
        },
      });

      // ENTRANCE (0-30%)
      scrollTl
        .fromTo(
          leftPanelRef.current,
          { x: '-60vw', opacity: 1 },
          { x: 0, opacity: 1, ease: 'none' },
          0
        )
        .fromTo(
          rightPanelRef.current,
          { x: '60vw', opacity: 1 },
          { x: 0, opacity: 1, ease: 'none' },
          0
        )
        .fromTo(
          dividerRef.current,
          { scaleY: 0 },
          { scaleY: 1, ease: 'none' },
          0.05
        )
        .fromTo(
          headlineRef.current,
          { y: '10vh', opacity: 0, rotateX: 18 },
          { y: 0, opacity: 1, rotateX: 0, ease: 'none' },
          0.1
        )
        .fromTo(
          priceRef.current,
          { y: '4vh', opacity: 0 },
          { y: 0, opacity: 1, ease: 'none' },
          0.16
        )
        .fromTo(
          ctaRef.current,
          { y: '6vh', scale: 0.94, opacity: 0 },
          { y: 0, scale: 1, opacity: 1, ease: 'none' },
          0.18
        );

      // EXIT (70-100%)
      scrollTl
        .to(leftPanelRef.current, {
          x: '-40vw',
          opacity: 0,
          ease: 'power2.in',
        }, 0.7)
        .to(rightPanelRef.current, {
          x: '40vw',
          opacity: 0,
          ease: 'power2.in',
        }, 0.7)
        .to(dividerRef.current, {
          scaleY: 0,
          ease: 'power2.in',
        }, 0.7)
        .to(headlineRef.current, {
          y: '-8vh',
          opacity: 0,
          ease: 'power2.in',
        }, 0.7)
        .to(priceRef.current, {
          opacity: 0,
          ease: 'power2.in',
        }, 0.72)
        .to(ctaRef.current, {
          y: '-4vh',
          opacity: 0,
          ease: 'power2.in',
        }, 0.74);
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      className="section-pinned bg-[#0B0B0D] z-50"
    >
      {/* Left Media Panel */}
      <div
        ref={leftPanelRef}
        className="absolute left-0 top-0 w-1/2 h-full overflow-hidden"
      >
        <img
          src="/signature_blazer_left.jpg"
          alt="Signature blazer"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-transparent to-[#0B0B0D]/30" />
      </div>

      {/* Right Media Panel */}
      <div
        ref={rightPanelRef}
        className="absolute right-0 top-0 w-1/2 h-full overflow-hidden"
      >
        <img
          src="/signature_blazer_right.jpg"
          alt="Signature blazer"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-l from-transparent to-[#0B0B0D]/30" />
      </div>

      {/* Center Divider */}
      <div
        ref={dividerRef}
        className="divider-line"
        style={{ transformOrigin: 'center' }}
      />

      {/* Center Content */}
      <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
        <h2
          ref={headlineRef}
          className="text-[#F4F1EA] text-4xl md:text-6xl lg:text-7xl font-black tracking-[0.1em] text-center mb-4"
          style={{ 
            textShadow: '0 4px 40px rgba(0,0,0,0.7)',
            perspective: '1000px'
          }}
        >
          SIGNATURE<br />BLAZER
        </h2>

        <p
          ref={priceRef}
          className="font-mono text-[#C9A86C] text-2xl md:text-3xl tracking-wider mb-8"
        >
          $189
        </p>

        <button
          ref={ctaRef}
          onClick={handleAddToBag}
          className="btn-gold pointer-events-auto text-sm tracking-[0.15em] font-semibold"
        >
          ADD TO BAG
        </button>
      </div>
    </section>
  );
}
