import { useRef, useLayoutEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { useCartStore } from '@/store/cartStore';
import { products } from '@/types/product';
import { ArrowRight } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

interface ShopDropSectionProps {
  onViewAll: () => void;
}

export function ShopDropSection({ onViewAll }: ShopDropSectionProps) {
  const sectionRef = useRef<HTMLDivElement>(null);
  const leftPanelRef = useRef<HTMLDivElement>(null);
  const rightPanelRef = useRef<HTMLDivElement>(null);
  const headlineRef = useRef<HTMLHeadingElement>(null);
  const subheadRef = useRef<HTMLParagraphElement>(null);
  const cardsRef = useRef<(HTMLDivElement | null)[]>([]);
  const viewAllRef = useRef<HTMLButtonElement>(null);
  const { addItem, toggleCart } = useCartStore();

  const featuredProducts = products.filter(p => p.featured).slice(0, 2);

  const handleAddToBag = (product: typeof products[0]) => {
    addItem({
      id: product.id,
      name: product.name,
      price: product.price,
      image: product.images[0],
      size: product.sizes[1],
    });
    toggleCart();
  };

  useLayoutEffect(() => {
    const ctx = gsap.context(() => {
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: sectionRef.current,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.6,
        },
      });

      // ENTRANCE (0-30%)
      scrollTl
        .fromTo(
          leftPanelRef.current,
          { x: '-60vw', opacity: 1 },
          { x: 0, opacity: 1, ease: 'none' },
          0
        )
        .fromTo(
          rightPanelRef.current,
          { x: '60vw', opacity: 1 },
          { x: 0, opacity: 1, ease: 'none' },
          0
        )
        .fromTo(
          headlineRef.current,
          { y: '6vh', opacity: 0 },
          { y: 0, opacity: 1, ease: 'none' },
          0.1
        )
        .fromTo(
          subheadRef.current,
          { y: '4vh', opacity: 0 },
          { y: 0, opacity: 1, ease: 'none' },
          0.12
        );

      // Cards staggered entrance
      cardsRef.current.forEach((card, i) => {
        if (card) {
          scrollTl.fromTo(
            card,
            { x: '8vw', opacity: 0, scale: 0.96 },
            { x: 0, opacity: 1, scale: 1, ease: 'none' },
            0.14 + i * 0.04
          );
        }
      });

      scrollTl.fromTo(
        viewAllRef.current,
        { y: '3vh', opacity: 0 },
        { y: 0, opacity: 1, ease: 'none' },
        0.22
      );

      // EXIT (70-100%)
      scrollTl
        .to(leftPanelRef.current, {
          x: '-40vw',
          opacity: 0,
          ease: 'power2.in',
        }, 0.7)
        .to(rightPanelRef.current, {
          x: '40vw',
          opacity: 0,
          ease: 'power2.in',
        }, 0.7)
        .to(headlineRef.current, {
          y: '-4vh',
          opacity: 0,
          ease: 'power2.in',
        }, 0.7)
        .to(subheadRef.current, {
          y: '-3vh',
          opacity: 0,
          ease: 'power2.in',
        }, 0.71);

      cardsRef.current.forEach((card) => {
        if (card) {
          scrollTl.to(card, {
            x: '6vw',
            opacity: 0,
            ease: 'power2.in',
          }, 0.7);
        }
      });

      scrollTl.to(viewAllRef.current, {
        y: '-2vh',
        opacity: 0,
        ease: 'power2.in',
      }, 0.74);
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      className="section-pinned bg-[#0B0B0D] z-[70]"
    >
      {/* Left Media Panel */}
      <div
        ref={leftPanelRef}
        className="absolute left-0 top-0 w-1/2 h-full overflow-hidden"
      >
        <img
          src="/shop_drop_left.jpg"
          alt="Limited release"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-transparent to-[#0B0B0D]/50" />
      </div>

      {/* Right Product Panel */}
      <div
        ref={rightPanelRef}
        className="absolute right-0 top-0 w-1/2 h-full flex flex-col justify-center px-8 lg:px-16"
      >
        <h2
          ref={headlineRef}
          className="text-[#F4F1EA] text-3xl md:text-4xl lg:text-5xl font-black tracking-[0.1em] mb-3"
        >
          LIMITED<br />RELEASE
        </h2>

        <p
          ref={subheadRef}
          className="text-[#A7A29A] text-sm tracking-[0.1em] mb-8"
        >
          Small batches. No restocks.
        </p>

        {/* Product Cards */}
        <div className="space-y-4 max-w-md">
          {featuredProducts.map((product, i) => (
            <div
              key={product.id}
              ref={(el) => { cardsRef.current[i] = el; }}
              className="product-card flex gap-4 p-3"
            >
              <img
                src={product.images[0]}
                alt={product.name}
                className="w-24 h-28 object-cover rounded-lg"
              />
              <div className="flex-1 flex flex-col justify-between">
                <div>
                  <h4 className="text-[#F4F1EA] text-sm font-medium line-clamp-1">
                    {product.name}
                  </h4>
                  <p className="text-[#C9A86C] font-mono text-lg mt-1">
                    ${product.price}
                  </p>
                </div>
                <button
                  onClick={() => handleAddToBag(product)}
                  className="self-start px-4 py-2 bg-[#C9A86C] text-[#0B0B0D] text-xs font-semibold tracking-wider rounded-full hover:bg-[#A88B55] transition-colors"
                >
                  ADD TO BAG
                </button>
              </div>
            </div>
          ))}
        </div>

        <button
          ref={viewAllRef}
          onClick={onViewAll}
          className="flex items-center gap-2 text-[#C9A86C] text-sm font-medium mt-6 hover:gap-4 transition-all"
        >
          View All
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </section>
  );
}
