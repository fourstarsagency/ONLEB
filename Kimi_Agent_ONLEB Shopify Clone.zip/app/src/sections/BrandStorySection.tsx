import { useRef, useLayoutEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ArrowRight } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

interface BrandStorySectionProps {
  onReadStory: () => void;
}

export function BrandStorySection({ onReadStory }: BrandStorySectionProps) {
  const sectionRef = useRef<HTMLDivElement>(null);
  const imageRef = useRef<HTMLImageElement>(null);
  const headlineRef = useRef<HTMLHeadingElement>(null);
  const paragraphsRef = useRef<(HTMLParagraphElement | null)[]>([]);
  const ctaRef = useRef<HTMLButtonElement>(null);

  useLayoutEffect(() => {
    const ctx = gsap.context(() => {
      // Image reveal
      gsap.fromTo(
        imageRef.current,
        { y: '8vh', opacity: 0, scale: 1.03 },
        {
          y: 0,
          opacity: 1,
          scale: 1,
          duration: 1,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 80%',
            end: 'top 45%',
            scrub: 1,
          },
        }
      );

      // Headline reveal
      gsap.fromTo(
        headlineRef.current,
        { y: '6vh', opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.8,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 75%',
            end: 'top 50%',
            scrub: 1,
          },
        }
      );

      // Paragraphs staggered reveal
      paragraphsRef.current.forEach((p, i) => {
        if (p) {
          gsap.fromTo(
            p,
            { y: '3vh', opacity: 0 },
            {
              y: 0,
              opacity: 1,
              duration: 0.6,
              ease: 'power2.out',
              scrollTrigger: {
                trigger: sectionRef.current,
                start: `top ${70 - i * 5}%`,
                end: `top ${45 - i * 5}%`,
                scrub: 1,
              },
            }
          );
        }
      });

      // CTA reveal
      gsap.fromTo(
        ctaRef.current,
        { y: '2vh', opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.6,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 55%',
            end: 'top 35%',
            scrub: 1,
          },
        }
      );
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  const paragraphs = [
    'We design for the in-between moments—commutes, coffee runs, late nights.',
    'Every piece is cut for motion, finished for texture, and built to last beyond the season.',
    'No logos. Just silhouette.',
  ];

  return (
    <section
      ref={sectionRef}
      className="relative bg-[#0B0B0D] py-24 lg:py-32 z-[80]"
    >
      <div className="max-w-7xl mx-auto px-6 lg:px-12">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-center">
          {/* Left: Text Content */}
          <div className="order-2 lg:order-1">
            <h2
              ref={headlineRef}
              className="text-[#F4F1EA] text-4xl md:text-5xl lg:text-6xl font-black tracking-[0.08em] mb-8"
            >
              MADE FOR<br />MOVEMENT
            </h2>

            <div className="space-y-4 mb-8">
              {paragraphs.map((text, i) => (
                <p
                  key={i}
                  ref={(el) => { paragraphsRef.current[i] = el; }}
                  className="text-[#A7A29A] text-base md:text-lg leading-relaxed"
                >
                  {text}
                </p>
              ))}
            </div>

            <button
              ref={ctaRef}
              onClick={onReadStory}
              className="flex items-center gap-2 text-[#C9A86C] text-sm font-medium hover:gap-4 transition-all group"
            >
              Read our story
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </button>
          </div>

          {/* Right: Image */}
          <div className="order-1 lg:order-2">
            <img
              ref={imageRef}
              src="/story_image.jpg"
              alt="Brand story"
              className="w-full aspect-[4/5] object-cover rounded-xl"
            />
          </div>
        </div>
      </div>
    </section>
  );
}
