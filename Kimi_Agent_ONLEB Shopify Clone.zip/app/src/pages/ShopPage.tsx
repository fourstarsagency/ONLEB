import { useState, useMemo } from 'react';
import { products, categories } from '@/types/product';
import { useCartStore } from '@/store/cartStore';
import { Filter, Grid3X3, LayoutList, ChevronDown } from 'lucide-react';
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from '@/components/ui/sheet';
import { toast } from 'sonner';

interface ShopPageProps {
  onProductClick: (productId: string) => void;
}

export function ShopPage({ onProductClick }: ShopPageProps) {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [sortBy, setSortBy] = useState<string>('featured');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [priceRange, setPriceRange] = useState<[number, number]>([0, 500]);
  const { addItem } = useCartStore();

  const filteredProducts = useMemo(() => {
    let result = [...products];

    // Filter by category
    if (selectedCategory !== 'all') {
      result = result.filter(p => p.category.toLowerCase() === selectedCategory.toLowerCase());
    }

    // Filter by price
    result = result.filter(p => p.price >= priceRange[0] && p.price <= priceRange[1]);

    // Sort
    switch (sortBy) {
      case 'price-low':
        result.sort((a, b) => a.price - b.price);
        break;
      case 'price-high':
        result.sort((a, b) => b.price - a.price);
        break;
      case 'newest':
        result.sort((a, b) => (b.new ? 1 : 0) - (a.new ? 1 : 0));
        break;
      default:
        // featured - keep original order
        break;
    }

    return result;
  }, [selectedCategory, sortBy, priceRange]);

  const handleQuickAdd = (e: React.MouseEvent, product: typeof products[0]) => {
    e.stopPropagation();
    addItem({
      id: product.id,
      name: product.name,
      price: product.price,
      image: product.images[0],
      size: product.sizes[1],
    });
    toast.success(`${product.name} added to bag`);
  };

  return (
    <div className="min-h-screen bg-[#0B0B0D] pt-24 pb-16">
      <div className="max-w-7xl mx-auto px-6 lg:px-12">
        {/* Header */}
        <div className="mb-12">
          <h1 className="text-[#F4F1EA] text-4xl md:text-5xl font-black tracking-[0.1em] mb-4">
            SHOP
          </h1>
          <p className="text-[#A7A29A] text-sm tracking-wider">
            {filteredProducts.length} PRODUCTS
          </p>
        </div>

        {/* Filters & Controls */}
        <div className="flex flex-wrap items-center justify-between gap-4 mb-8 pb-6 border-b border-[#F4F1EA]/10">
          {/* Category Pills */}
          <div className="flex flex-wrap gap-2">
            <button
              onClick={() => setSelectedCategory('all')}
              className={`px-4 py-2 text-xs font-medium tracking-wider rounded-full transition-all ${
                selectedCategory === 'all'
                  ? 'bg-[#C9A86C] text-[#0B0B0D]'
                  : 'bg-[#141419] text-[#F4F1EA] hover:bg-[#C9A86C]/20'
              }`}
            >
              ALL
            </button>
            {categories.map((cat) => (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className={`px-4 py-2 text-xs font-medium tracking-wider rounded-full transition-all ${
                  selectedCategory === cat.id
                    ? 'bg-[#C9A86C] text-[#0B0B0D]'
                    : 'bg-[#141419] text-[#F4F1EA] hover:bg-[#C9A86C]/20'
                }`}
              >
                {cat.name.toUpperCase()}
              </button>
            ))}
          </div>

          {/* Right Controls */}
          <div className="flex items-center gap-4">
            {/* Sort Dropdown */}
            <div className="relative">
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value)}
                className="appearance-none bg-[#141419] text-[#F4F1EA] text-xs tracking-wider px-4 py-2 pr-10 rounded-full border border-[#F4F1EA]/10 focus:border-[#C9A86C] focus:outline-none"
              >
                <option value="featured">FEATURED</option>
                <option value="newest">NEWEST</option>
                <option value="price-low">PRICE: LOW TO HIGH</option>
                <option value="price-high">PRICE: HIGH TO LOW</option>
              </select>
              <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#A7A29A] pointer-events-none" />
            </div>

            {/* View Mode Toggle */}
            <div className="flex bg-[#141419] rounded-full p-1">
              <button
                onClick={() => setViewMode('grid')}
                className={`p-2 rounded-full transition-colors ${
                  viewMode === 'grid' ? 'bg-[#C9A86C] text-[#0B0B0D]' : 'text-[#A7A29A]'
                }`}
              >
                <Grid3X3 className="w-4 h-4" />
              </button>
              <button
                onClick={() => setViewMode('list')}
                className={`p-2 rounded-full transition-colors ${
                  viewMode === 'list' ? 'bg-[#C9A86C] text-[#0B0B0D]' : 'text-[#A7A29A]'
                }`}
              >
                <LayoutList className="w-4 h-4" />
              </button>
            </div>

            {/* Mobile Filter */}
            <Sheet>
              <SheetTrigger asChild>
                <button className="lg:hidden p-2 bg-[#141419] rounded-full text-[#F4F1EA]">
                  <Filter className="w-4 h-4" />
                </button>
              </SheetTrigger>
              <SheetContent side="right" className="bg-[#0B0B0D] border-l border-[#C9A86C]/20 w-80">
                <SheetHeader>
                  <SheetTitle className="text-[#F4F1EA] font-mono tracking-wider">FILTERS</SheetTitle>
                </SheetHeader>
                <div className="py-6">
                  <div className="mb-6">
                    <h4 className="text-[#F4F1EA] text-sm font-medium mb-3">Price Range</h4>
                    <input
                      type="range"
                      min="0"
                      max="500"
                      value={priceRange[1]}
                      onChange={(e) => setPriceRange([0, parseInt(e.target.value)])}
                      className="w-full accent-[#C9A86C]"
                    />
                    <div className="flex justify-between text-[#A7A29A] text-sm mt-2">
                      <span>$0</span>
                      <span>${priceRange[1]}</span>
                    </div>
                  </div>
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </div>

        {/* Products Grid */}
        <div className={`grid ${
          viewMode === 'grid'
            ? 'grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4'
            : 'grid-cols-1'
        } gap-6`}>
          {filteredProducts.map((product) => (
            <div
              key={product.id}
              onClick={() => onProductClick(product.id)}
              className={`group cursor-pointer ${
                viewMode === 'list' ? 'flex gap-6 bg-[#141419] p-4 rounded-xl' : ''
              }`}
            >
              {/* Image */}
              <div className={`relative overflow-hidden rounded-xl ${
                viewMode === 'list' ? 'w-48 h-56 flex-shrink-0' : 'aspect-[3/4] mb-4'
              }`}>
                <img
                  src={product.images[0]}
                  alt={product.name}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                
                {/* Badges */}
                <div className="absolute top-3 left-3 flex flex-col gap-2">
                  {product.new && (
                    <span className="px-2 py-1 bg-[#C9A86C] text-[#0B0B0D] text-[10px] font-bold tracking-wider">
                      NEW
                    </span>
                  )}
                  {product.originalPrice && (
                    <span className="px-2 py-1 bg-[#0B0B0D] text-[#C9A86C] text-[10px] font-bold tracking-wider">
                      SALE
                    </span>
                  )}
                </div>

                {/* Quick Add */}
                <button
                  onClick={(e) => handleQuickAdd(e, product)}
                  className={`absolute bottom-3 left-3 right-3 py-3 bg-[#C9A86C] text-[#0B0B0D] text-xs font-semibold tracking-wider opacity-0 group-hover:opacity-100 transition-opacity ${
                    viewMode === 'list' ? 'hidden' : ''
                  }`}
                >
                  QUICK ADD
                </button>
              </div>

              {/* Info */}
              <div className="flex-1 flex flex-col justify-center">
                <h3 className="text-[#F4F1EA] font-medium text-sm mb-1 group-hover:text-[#C9A86C] transition-colors">
                  {product.name}
                </h3>
                <p className="text-[#A7A29A] text-xs mb-2">{product.category}</p>
                <div className="flex items-center gap-2">
                  <span className="text-[#C9A86C] font-mono">${product.price}</span>
                  {product.originalPrice && (
                    <span className="text-[#A7A29A] text-sm line-through">
                      ${product.originalPrice}
                    </span>
                  )}
                </div>
                
                {viewMode === 'list' && (
                  <button
                    onClick={(e) => handleQuickAdd(e, product)}
                    className="mt-4 self-start px-6 py-2 bg-[#C9A86C] text-[#0B0B0D] text-xs font-semibold tracking-wider rounded-full hover:bg-[#A88B55] transition-colors"
                  >
                    ADD TO BAG
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>

        {filteredProducts.length === 0 && (
          <div className="text-center py-20">
            <p className="text-[#A7A29A] text-lg">No products found</p>
          </div>
        )}
      </div>
    </div>
  );
}
