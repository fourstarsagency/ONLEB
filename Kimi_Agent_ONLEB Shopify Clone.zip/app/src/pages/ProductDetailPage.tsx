import { useState } from 'react';
import { products } from '@/types/product';
import { useCartStore } from '@/store/cartStore';
import { ChevronLeft, Plus, Minus, Heart, Share2, Truck, RotateCcw, Shield } from 'lucide-react';
import { toast } from 'sonner';

interface ProductDetailPageProps {
  productId: string;
  onBack: () => void;
}

export function ProductDetailPage({ productId, onBack }: ProductDetailPageProps) {
  const product = products.find(p => p.id === productId);
  const [selectedSize, setSelectedSize] = useState<string>('');
  const [selectedImage, setSelectedImage] = useState(0);
  const [quantity, setQuantity] = useState(1);
  const [isWishlisted, setIsWishlisted] = useState(false);
  const { addItem, toggleCart } = useCartStore();

  if (!product) {
    return (
      <div className="min-h-screen bg-[#0B0B0D] flex items-center justify-center">
        <p className="text-[#A7A29A]">Product not found</p>
      </div>
    );
  }

  const handleAddToBag = () => {
    if (!selectedSize) {
      toast.error('Please select a size');
      return;
    }
    
    for (let i = 0; i < quantity; i++) {
      addItem({
        id: product.id,
        name: product.name,
        price: product.price,
        image: product.images[0],
        size: selectedSize,
      });
    }
    
    toast.success(`${product.name} added to bag`);
    toggleCart();
  };

  const handleWishlist = () => {
    setIsWishlisted(!isWishlisted);
    toast.success(isWishlisted ? 'Removed from wishlist' : 'Added to wishlist');
  };

  return (
    <div className="min-h-screen bg-[#0B0B0D] pt-24 pb-16">
      <div className="max-w-7xl mx-auto px-6 lg:px-12">
        {/* Back Button */}
        <button
          onClick={onBack}
          className="flex items-center gap-2 text-[#A7A29A] hover:text-[#C9A86C] transition-colors mb-8"
        >
          <ChevronLeft className="w-5 h-5" />
          Back to Shop
        </button>

        <div className="grid lg:grid-cols-2 gap-12">
          {/* Left: Images */}
          <div>
            {/* Main Image */}
            <div className="aspect-[3/4] rounded-xl overflow-hidden mb-4">
              <img
                src={product.images[selectedImage]}
                alt={product.name}
                className="w-full h-full object-cover"
              />
            </div>

            {/* Thumbnails */}
            {product.images.length > 1 && (
              <div className="flex gap-3">
                {product.images.map((img, i) => (
                  <button
                    key={i}
                    onClick={() => setSelectedImage(i)}
                    className={`w-20 h-24 rounded-lg overflow-hidden border-2 transition-colors ${
                      selectedImage === i ? 'border-[#C9A86C]' : 'border-transparent'
                    }`}
                  >
                    <img
                      src={img}
                      alt={`${product.name} ${i + 1}`}
                      className="w-full h-full object-cover"
                    />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Right: Info */}
          <div className="lg:py-8">
            {/* Category & Badges */}
            <div className="flex items-center gap-3 mb-4">
              <span className="text-[#A7A29A] text-sm tracking-wider">{product.category.toUpperCase()}</span>
              {product.new && (
                <span className="px-2 py-1 bg-[#C9A86C] text-[#0B0B0D] text-[10px] font-bold tracking-wider">
                  NEW
                </span>
              )}
            </div>

            {/* Name */}
            <h1 className="text-[#F4F1EA] text-3xl md:text-4xl font-black tracking-[0.05em] mb-4">
              {product.name}
            </h1>

            {/* Price */}
            <div className="flex items-center gap-3 mb-6">
              <span className="text-[#C9A86C] text-2xl font-mono">${product.price}</span>
              {product.originalPrice && (
                <>
                  <span className="text-[#A7A29A] text-lg line-through">
                    ${product.originalPrice}
                  </span>
                  <span className="px-2 py-1 bg-[#C9A86C]/20 text-[#C9A86C] text-xs font-bold">
                    SAVE ${product.originalPrice - product.price}
                  </span>
                </>
              )}
            </div>

            {/* Description */}
            <p className="text-[#A7A29A] leading-relaxed mb-8">
              {product.description}
            </p>

            {/* Size Selection */}
            <div className="mb-8">
              <div className="flex items-center justify-between mb-3">
                <span className="text-[#F4F1EA] text-sm font-medium">Select Size</span>
                <button className="text-[#C9A86C] text-xs underline">Size Guide</button>
              </div>
              <div className="flex flex-wrap gap-2">
                {product.sizes.map((size) => (
                  <button
                    key={size}
                    onClick={() => setSelectedSize(size)}
                    className={`w-12 h-12 rounded-lg font-medium text-sm transition-all ${
                      selectedSize === size
                        ? 'bg-[#C9A86C] text-[#0B0B0D]'
                        : 'bg-[#141419] text-[#F4F1EA] hover:bg-[#C9A86C]/20'
                    }`}
                  >
                    {size}
                  </button>
                ))}
              </div>
            </div>

            {/* Quantity */}
            <div className="mb-8">
              <span className="text-[#F4F1EA] text-sm font-medium mb-3 block">Quantity</span>
              <div className="flex items-center gap-3">
                <button
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  className="w-10 h-10 flex items-center justify-center bg-[#141419] rounded-lg text-[#F4F1EA] hover:bg-[#C9A86C] hover:text-[#0B0B0D] transition-colors"
                >
                  <Minus className="w-4 h-4" />
                </button>
                <span className="text-[#F4F1EA] font-medium w-8 text-center">{quantity}</span>
                <button
                  onClick={() => setQuantity(quantity + 1)}
                  className="w-10 h-10 flex items-center justify-center bg-[#141419] rounded-lg text-[#F4F1EA] hover:bg-[#C9A86C] hover:text-[#0B0B0D] transition-colors"
                >
                  <Plus className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Actions */}
            <div className="flex gap-3 mb-8">
              <button
                onClick={handleAddToBag}
                className="flex-1 btn-gold h-14 text-sm font-semibold tracking-wider"
              >
                ADD TO BAG
              </button>
              <button
                onClick={handleWishlist}
                className={`w-14 h-14 flex items-center justify-center rounded-full border-2 transition-colors ${
                  isWishlisted
                    ? 'bg-[#C9A86C] border-[#C9A86C] text-[#0B0B0D]'
                    : 'border-[#F4F1EA]/20 text-[#F4F1EA] hover:border-[#C9A86C]'
                }`}
              >
                <Heart className={`w-5 h-5 ${isWishlisted ? 'fill-current' : ''}`} />
              </button>
              <button
                onClick={() => toast.success('Link copied to clipboard')}
                className="w-14 h-14 flex items-center justify-center rounded-full border-2 border-[#F4F1EA]/20 text-[#F4F1EA] hover:border-[#C9A86C] transition-colors"
              >
                <Share2 className="w-5 h-5" />
              </button>
            </div>

            {/* Features */}
            <div className="grid grid-cols-3 gap-4 pt-8 border-t border-[#F4F1EA]/10">
              <div className="text-center">
                <Truck className="w-6 h-6 text-[#C9A86C] mx-auto mb-2" />
                <p className="text-[#A7A29A] text-xs">Free Shipping</p>
              </div>
              <div className="text-center">
                <RotateCcw className="w-6 h-6 text-[#C9A86C] mx-auto mb-2" />
                <p className="text-[#A7A29A] text-xs">Easy Returns</p>
              </div>
              <div className="text-center">
                <Shield className="w-6 h-6 text-[#C9A86C] mx-auto mb-2" />
                <p className="text-[#A7A29A] text-xs">Secure Payment</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
