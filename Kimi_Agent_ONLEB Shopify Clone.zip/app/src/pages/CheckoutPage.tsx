import { useState } from 'react';
import { useCartStore } from '@/store/cartStore';
import { ChevronLeft, CreditCard, Truck, Check } from 'lucide-react';
import { toast } from 'sonner';

interface CheckoutPageProps {
  onBack: () => void;
  onComplete: () => void;
}

export function CheckoutPage({ onBack, onComplete }: CheckoutPageProps) {
  const { items, getTotalPrice, clearCart } = useCartStore();
  const [step, setStep] = useState<'shipping' | 'payment' | 'review'>('shipping');
  const [isProcessing, setIsProcessing] = useState(false);

  const [shippingInfo, setShippingInfo] = useState({
    firstName: '',
    lastName: '',
    email: '',
    address: '',
    city: '',
    zipCode: '',
    country: 'US',
  });

  const [paymentInfo, setPaymentInfo] = useState({
    cardNumber: '',
    expiryDate: '',
    cvv: '',
    cardName: '',
  });

  const handleShippingSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setStep('payment');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handlePaymentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setStep('review');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handlePlaceOrder = async () => {
    setIsProcessing(true);
    
    // Simulate order processing
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    toast.success('Order placed successfully!');
    clearCart();
    setIsProcessing(false);
    onComplete();
  };

  const subtotal = getTotalPrice();
  const shipping = subtotal > 200 ? 0 : 15;
  const tax = subtotal * 0.08;
  const total = subtotal + shipping + tax;

  if (items.length === 0) {
    return (
      <div className="min-h-screen bg-[#0B0B0D] flex flex-col items-center justify-center pt-24">
        <div className="text-center">
          <h2 className="text-[#F4F1EA] text-2xl font-bold mb-4">Your bag is empty</h2>
          <p className="text-[#A7A29A] mb-6">Add items to proceed with checkout</p>
          <button onClick={onBack} className="btn-gold">
            CONTINUE SHOPPING
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0B0B0D] pt-24 pb-16">
      <div className="max-w-6xl mx-auto px-6 lg:px-12">
        {/* Back Button */}
        <button
          onClick={onBack}
          className="flex items-center gap-2 text-[#A7A29A] hover:text-[#C9A86C] transition-colors mb-8"
        >
          <ChevronLeft className="w-5 h-5" />
          Back to Shop
        </button>

        {/* Progress */}
        <div className="flex items-center justify-center mb-12">
          <div className="flex items-center gap-4">
            <div className={`flex items-center gap-2 ${step === 'shipping' ? 'text-[#C9A86C]' : 'text-[#F4F1EA]'}`}>
              <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                step === 'shipping' ? 'bg-[#C9A86C] text-[#0B0B0D]' : 'bg-[#141419]'
              }`}>
                <Truck className="w-4 h-4" />
              </div>
              <span className="text-sm font-medium hidden sm:block">Shipping</span>
            </div>
            <div className="w-12 h-px bg-[#F4F1EA]/20" />
            <div className={`flex items-center gap-2 ${step === 'payment' ? 'text-[#C9A86C]' : 'text-[#F4F1EA]'}`}>
              <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                step === 'payment' ? 'bg-[#C9A86C] text-[#0B0B0D]' : 'bg-[#141419]'
              }`}>
                <CreditCard className="w-4 h-4" />
              </div>
              <span className="text-sm font-medium hidden sm:block">Payment</span>
            </div>
            <div className="w-12 h-px bg-[#F4F1EA]/20" />
            <div className={`flex items-center gap-2 ${step === 'review' ? 'text-[#C9A86C]' : 'text-[#F4F1EA]'}`}>
              <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                step === 'review' ? 'bg-[#C9A86C] text-[#0B0B0D]' : 'bg-[#141419]'
              }`}>
                <Check className="w-4 h-4" />
              </div>
              <span className="text-sm font-medium hidden sm:block">Review</span>
            </div>
          </div>
        </div>

        <div className="grid lg:grid-cols-3 gap-12">
          {/* Main Content */}
          <div className="lg:col-span-2">
            {step === 'shipping' && (
              <form onSubmit={handleShippingSubmit} className="space-y-6">
                <h2 className="text-[#F4F1EA] text-2xl font-bold mb-6">Shipping Information</h2>
                
                <div className="grid sm:grid-cols-2 gap-4">
                  <div>
                    <label className="text-[#A7A29A] text-sm mb-2 block">First Name</label>
                    <input
                      type="text"
                      required
                      value={shippingInfo.firstName}
                      onChange={(e) => setShippingInfo({ ...shippingInfo, firstName: e.target.value })}
                      className="input-dark w-full"
                      placeholder="John"
                    />
                  </div>
                  <div>
                    <label className="text-[#A7A29A] text-sm mb-2 block">Last Name</label>
                    <input
                      type="text"
                      required
                      value={shippingInfo.lastName}
                      onChange={(e) => setShippingInfo({ ...shippingInfo, lastName: e.target.value })}
                      className="input-dark w-full"
                      placeholder="Doe"
                    />
                  </div>
                </div>

                <div>
                  <label className="text-[#A7A29A] text-sm mb-2 block">Email</label>
                  <input
                    type="email"
                    required
                    value={shippingInfo.email}
                    onChange={(e) => setShippingInfo({ ...shippingInfo, email: e.target.value })}
                    className="input-dark w-full"
                    placeholder="john@example.com"
                  />
                </div>

                <div>
                  <label className="text-[#A7A29A] text-sm mb-2 block">Address</label>
                  <input
                    type="text"
                    required
                    value={shippingInfo.address}
                    onChange={(e) => setShippingInfo({ ...shippingInfo, address: e.target.value })}
                    className="input-dark w-full"
                    placeholder="123 Main St"
                  />
                </div>

                <div className="grid sm:grid-cols-3 gap-4">
                  <div>
                    <label className="text-[#A7A29A] text-sm mb-2 block">City</label>
                    <input
                      type="text"
                      required
                      value={shippingInfo.city}
                      onChange={(e) => setShippingInfo({ ...shippingInfo, city: e.target.value })}
                      className="input-dark w-full"
                      placeholder="New York"
                    />
                  </div>
                  <div>
                    <label className="text-[#A7A29A] text-sm mb-2 block">ZIP Code</label>
                    <input
                      type="text"
                      required
                      value={shippingInfo.zipCode}
                      onChange={(e) => setShippingInfo({ ...shippingInfo, zipCode: e.target.value })}
                      className="input-dark w-full"
                      placeholder="10001"
                    />
                  </div>
                  <div>
                    <label className="text-[#A7A29A] text-sm mb-2 block">Country</label>
                    <select
                      value={shippingInfo.country}
                      onChange={(e) => setShippingInfo({ ...shippingInfo, country: e.target.value })}
                      className="input-dark w-full"
                    >
                      <option value="US">United States</option>
                      <option value="CA">Canada</option>
                      <option value="UK">United Kingdom</option>
                      <option value="EU">Europe</option>
                    </select>
                  </div>
                </div>

                <button type="submit" className="btn-gold w-full h-14 mt-6">
                  CONTINUE TO PAYMENT
                </button>
              </form>
            )}

            {step === 'payment' && (
              <form onSubmit={handlePaymentSubmit} className="space-y-6">
                <h2 className="text-[#F4F1EA] text-2xl font-bold mb-6">Payment Information</h2>
                
                <div>
                  <label className="text-[#A7A29A] text-sm mb-2 block">Card Number</label>
                  <input
                    type="text"
                    required
                    maxLength={19}
                    value={paymentInfo.cardNumber}
                    onChange={(e) => setPaymentInfo({ ...paymentInfo, cardNumber: e.target.value })}
                    className="input-dark w-full"
                    placeholder="1234 5678 9012 3456"
                  />
                </div>

                <div>
                  <label className="text-[#A7A29A] text-sm mb-2 block">Cardholder Name</label>
                  <input
                    type="text"
                    required
                    value={paymentInfo.cardName}
                    onChange={(e) => setPaymentInfo({ ...paymentInfo, cardName: e.target.value })}
                    className="input-dark w-full"
                    placeholder="John Doe"
                  />
                </div>

                <div className="grid sm:grid-cols-2 gap-4">
                  <div>
                    <label className="text-[#A7A29A] text-sm mb-2 block">Expiry Date</label>
                    <input
                      type="text"
                      required
                      maxLength={5}
                      value={paymentInfo.expiryDate}
                      onChange={(e) => setPaymentInfo({ ...paymentInfo, expiryDate: e.target.value })}
                      className="input-dark w-full"
                      placeholder="MM/YY"
                    />
                  </div>
                  <div>
                    <label className="text-[#A7A29A] text-sm mb-2 block">CVV</label>
                    <input
                      type="text"
                      required
                      maxLength={4}
                      value={paymentInfo.cvv}
                      onChange={(e) => setPaymentInfo({ ...paymentInfo, cvv: e.target.value })}
                      className="input-dark w-full"
                      placeholder="123"
                    />
                  </div>
                </div>

                <div className="flex gap-4 mt-6">
                  <button
                    type="button"
                    onClick={() => setStep('shipping')}
                    className="flex-1 btn-outline h-14"
                  >
                    BACK
                  </button>
                  <button type="submit" className="flex-1 btn-gold h-14">
                    REVIEW ORDER
                  </button>
                </div>
              </form>
            )}

            {step === 'review' && (
              <div className="space-y-6">
                <h2 className="text-[#F4F1EA] text-2xl font-bold mb-6">Review Your Order</h2>
                
                {/* Items */}
                <div className="bg-[#141419] rounded-xl p-6">
                  <h3 className="text-[#F4F1EA] font-medium mb-4">Items</h3>
                  <div className="space-y-4">
                    {items.map((item) => (
                      <div key={`${item.id}-${item.size}`} className="flex gap-4">
                        <img
                          src={item.image}
                          alt={item.name}
                          className="w-16 h-20 object-cover rounded-lg"
                        />
                        <div className="flex-1">
                          <h4 className="text-[#F4F1EA] text-sm font-medium">{item.name}</h4>
                          <p className="text-[#A7A29A] text-xs">Size: {item.size}</p>
                          <p className="text-[#A7A29A] text-xs">Qty: {item.quantity}</p>
                        </div>
                        <p className="text-[#C9A86C] font-mono">
                          ${(item.price * item.quantity).toFixed(0)}
                        </p>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Shipping */}
                <div className="bg-[#141419] rounded-xl p-6">
                  <h3 className="text-[#F4F1EA] font-medium mb-4">Shipping To</h3>
                  <p className="text-[#A7A29A] text-sm">
                    {shippingInfo.firstName} {shippingInfo.lastName}<br />
                    {shippingInfo.address}<br />
                    {shippingInfo.city}, {shippingInfo.zipCode}<br />
                    {shippingInfo.country}
                  </p>
                </div>

                <div className="flex gap-4 mt-6">
                  <button
                    onClick={() => setStep('payment')}
                    className="flex-1 btn-outline h-14"
                  >
                    BACK
                  </button>
                  <button
                    onClick={handlePlaceOrder}
                    disabled={isProcessing}
                    className="flex-1 btn-gold h-14 disabled:opacity-50"
                  >
                    {isProcessing ? 'PROCESSING...' : 'PLACE ORDER'}
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Order Summary */}
          <div className="lg:col-span-1">
            <div className="bg-[#141419] rounded-xl p-6 sticky top-24">
              <h3 className="text-[#F4F1EA] font-bold text-lg mb-6">Order Summary</h3>
              
              <div className="space-y-3 mb-6">
                <div className="flex justify-between text-sm">
                  <span className="text-[#A7A29A]">Subtotal</span>
                  <span className="text-[#F4F1EA]">${subtotal.toFixed(0)}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-[#A7A29A]">Shipping</span>
                  <span className="text-[#F4F1EA]">
                    {shipping === 0 ? 'FREE' : `$${shipping}`}
                  </span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-[#A7A29A]">Tax</span>
                  <span className="text-[#F4F1EA]">${tax.toFixed(0)}</span>
                </div>
              </div>

              <div className="border-t border-[#F4F1EA]/10 pt-4">
                <div className="flex justify-between">
                  <span className="text-[#F4F1EA] font-bold">Total</span>
                  <span className="text-[#C9A86C] font-mono text-xl">${total.toFixed(0)}</span>
                </div>
              </div>

              {subtotal < 200 && (
                <p className="text-[#A7A29A] text-xs mt-4">
                  Add ${(200 - subtotal).toFixed(0)} more for free shipping
                </p>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
